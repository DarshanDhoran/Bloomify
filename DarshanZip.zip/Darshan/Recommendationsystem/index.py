from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.template import RequestContext
import pymysql
from datetime import date
from django.core.mail import EmailMessage
from django.template.loader import render_to_string
from django.conf import settings
from django.contrib import messages
import random
import pandas as pd
from urllib.request import Request, urlopen
from django.core.files.storage import FileSystemStorage
import cv2
import pytesseract
from tkinter import Tk, Button, Label, filedialog
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from fuzzywuzzy import process
import spacy

def about(request):
    return render(request, "about.html")

def multianalyze1(request):
    return render(request, "multianalyze1.html")

def uploadimage(request):
    content = {}
    payload = []
    folder = 'static/'
    title = request.POST.get('title')
    print(title)
    myfile = request.FILES['image']
    print("myfile", myfile)
    fs = FileSystemStorage(folder)
    filename = fs.save(myfile.name, myfile)
    uploaded_file_url = fs.url(filename)
    print("url" + uploaded_file_url)
    file_path = "D:/DarshanBloom/Darshan/static/" + str(myfile)
    image = cv2.imread(file_path)
    # Adjusting contrast
    alpha = 1.4  # Contrast control
    beta = 0  # Brightness control
    new_image = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
    # Converting to grayscale
    gray_image = cv2.cvtColor(new_image, cv2.COLOR_BGR2GRAY)
    # Thresholding the image
    ret, thresh1 = cv2.threshold(gray_image, 127, 255, cv2.THRESH_BINARY)
    # Saving the thresholded image
    cv2.imwrite('thresholded_image.png', thresh1)
    # Tesseract configuration
    config = '-l eng --oem 1 --psm 3'
    # Performing OCR on the image
    text = pytesseract.image_to_string(thresh1, config=config)
    print(text)
    with open('extracted_text.txt', 'w') as file:
        content = {}
        content = {'data11': text}
        payload.append(content)
        content = {}
        file.write(text)
    return render(request, "multianalyze.html", {'list': {'items': payload}})

def multianalyze(request):
    content = {}
    payload = []
    q1 = request.POST.get('q1')
    stm = q1.split("\n")
    df = pd.read_csv('D:/DarshanBloom/Darshan/DataSet2.csv', encoding='unicode_escape')
    df = df.apply(lambda x: x.str.lower() if x.dtype == "object" else x)
    result = ""
    question = ""
    for x in stm:
        question = x
        spl = x.split(" ")
        for x in spl:
            try:
                x = x + ","
                print(x)
                df1 = df[df['Keywords'].str.contains(x.lower())]
                result = df1['Bloom Level'].iloc[0]
            except:
                print("No match Found")
        content = {}
        content = {'q1': question, 'res': result}
        payload.append(content)
        content = {}
    print(payload)
    return render(request, "multianalyze.html", {'list1': {'items': payload}})

def analyze(request):
    content = {}
    payload = []
    q1 = request.POST.get('q1')
    print(q1)
    nltk.download('stopwords')
    df = pd.read_csv('D:/DarshanBloom/Darshan/Dataset2.csv', encoding='unicode_escape')
    df = df.apply(lambda x: x.str.lower() if x.dtype == "object" else x)

    # Tokenization, stop word removal, and lemmatization
    def preprocess_text(text):
        word_tokens = word_tokenize(text)
        stop_words = set(stopwords.words('english'))
        filtered_text = [w for w in word_tokens if not w in stop_words]
        lemmatizer = WordNetLemmatizer()
        lemmatized_text = [lemmatizer.lemmatize(word) for word in filtered_text]
        return lemmatized_text

    # Perform fuzzy matching to find closest match in dataset
    def fuzzy_keyword_matching(question, dataset_keywords):
        matching_scores = {}
        for keyword in preprocess_text(question):
            for dataset_keyword in dataset_keywords:
                score = process.extractOne(keyword, dataset_keyword.split(", "))[1]
                if score > 80:  # Adjust threshold as needed
                    matching_scores[dataset_keyword] = score
        return matching_scores

    # Load and preprocess dataset
    df['Keywords'] = df['Keywords'].str.lower()

    # Perform fuzzy matching to find matching keywords in the dataset
    matching_scores = fuzzy_keyword_matching(q1, df['Keywords'])

    if matching_scores:
        # Retrieve Bloom Level for the highest scoring keyword
        max_score_keyword = max(matching_scores, key=matching_scores.get)
        bloom_level = df.loc[df['Keywords'] == max_score_keyword, 'Bloom Level'].iloc[0]
        payload.append({'question': q1, 'predicted_bloom_level': bloom_level})
    else:
        payload.append({'question': q1, 'predicted_bloom_level': 'Not found'})

    return render(request, "admindashboard.html", {'list': {'items': payload}})

def about(request):
    return render(request, "about.html")

def nanalyze(request):
    return render(request, "nanalyze.html")
